var searchData=
[
  ['recommended_20usage_20patterns_0',['Recommended usage patterns',['../usage_patterns.html',1,'index']]],
  ['resource_20aliasing_20_28overlap_29_1',['Resource aliasing (overlap)',['../resource_aliasing.html',1,'index']]]
];
