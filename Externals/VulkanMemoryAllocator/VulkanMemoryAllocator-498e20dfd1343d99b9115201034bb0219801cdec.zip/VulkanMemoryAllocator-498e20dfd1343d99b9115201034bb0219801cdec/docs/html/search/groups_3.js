var searchData=
[
  ['virtual_20allocator_0',['Virtual allocator',['../group__group__virtual.html',1,'']]]
];
