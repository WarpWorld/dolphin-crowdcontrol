var searchData=
[
  ['offset_0',['offset',['../struct_vma_allocation_info.html#a4a3c732388dbdc7a23f9365b00825268',1,'VmaAllocationInfo::offset()'],['../struct_vma_virtual_allocation_info.html#accb40a8205f49ccca3de975da7d1a2b5',1,'VmaVirtualAllocationInfo::offset()']]],
  ['opengl_20interop_1',['OpenGL Interop',['../opengl_interop.html',1,'index']]],
  ['operation_2',['operation',['../struct_vma_defragmentation_move.html#a20996a4686c9246dff77b375ac4a91e2',1,'VmaDefragmentationMove']]]
];
