var searchData=
[
  ['size_0',['size',['../struct_vma_allocation_info.html#aac76d113a6a5ccbb09fea00fb25fd18f',1,'VmaAllocationInfo::size()'],['../struct_vma_virtual_block_create_info.html#a670ab8c6a6e822f3c36781d79e8824e9',1,'VmaVirtualBlockCreateInfo::size()'],['../struct_vma_virtual_allocation_create_info.html#aae08752b86817abd0d944c6025dc603e',1,'VmaVirtualAllocationCreateInfo::size()'],['../struct_vma_virtual_allocation_info.html#afb6d6bd0a6813869ea0842048d40aa2b',1,'VmaVirtualAllocationInfo::size()']]],
  ['srcallocation_1',['srcAllocation',['../struct_vma_defragmentation_move.html#a25aa1bb64efc507a49c6cbc50689f862',1,'VmaDefragmentationMove']]],
  ['statistics_2',['statistics',['../struct_vma_detailed_statistics.html#a13efbdb35bd1291191d275f43e96d360',1,'VmaDetailedStatistics::statistics()'],['../struct_vma_budget.html#a6d15ab3a798fd62d9efa3a1e1f83bf54',1,'VmaBudget::statistics()']]]
];
