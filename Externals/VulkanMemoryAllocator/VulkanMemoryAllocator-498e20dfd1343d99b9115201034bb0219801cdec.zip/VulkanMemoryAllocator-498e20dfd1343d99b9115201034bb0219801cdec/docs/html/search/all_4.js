var searchData=
[
  ['enabling_20buffer_20device_20address_0',['Enabling buffer device address',['../enabling_buffer_device_address.html',1,'index']]]
];
