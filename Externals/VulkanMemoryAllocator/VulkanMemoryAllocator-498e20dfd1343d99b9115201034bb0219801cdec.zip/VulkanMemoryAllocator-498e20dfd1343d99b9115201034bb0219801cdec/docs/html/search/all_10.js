var searchData=
[
  ['unusedrangecount_0',['unusedRangeCount',['../struct_vma_detailed_statistics.html#ab721bf04892e8b67802d4ddb7734638a',1,'VmaDetailedStatistics']]],
  ['unusedrangesizemax_1',['unusedRangeSizeMax',['../struct_vma_detailed_statistics.html#af98943b5da98cf441ffa04b67914c78c',1,'VmaDetailedStatistics']]],
  ['unusedrangesizemin_2',['unusedRangeSizeMin',['../struct_vma_detailed_statistics.html#a830eda847ed735d0e91da25cfcf797a4',1,'VmaDetailedStatistics']]],
  ['usage_3',['usage',['../struct_vma_budget.html#a84dd1ecca8b0110259eb206dbadb11f6',1,'VmaBudget::usage()'],['../struct_vma_allocation_create_info.html#accb8b06b1f677d858cb9af20705fa910',1,'VmaAllocationCreateInfo::usage()']]]
];
