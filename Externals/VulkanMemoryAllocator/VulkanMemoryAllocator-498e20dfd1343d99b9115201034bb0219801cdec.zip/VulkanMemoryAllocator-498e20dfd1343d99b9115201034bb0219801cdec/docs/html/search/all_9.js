var searchData=
[
  ['maxallocationsperpass_0',['maxAllocationsPerPass',['../struct_vma_defragmentation_info.html#ac2db29d309bebc4f7d55041416e9694b',1,'VmaDefragmentationInfo']]],
  ['maxblockcount_1',['maxBlockCount',['../struct_vma_pool_create_info.html#ae41142f2834fcdc82baa4883c187b75c',1,'VmaPoolCreateInfo']]],
  ['maxbytesperpass_2',['maxBytesPerPass',['../struct_vma_defragmentation_info.html#a637ada77b02179a27fa92290000afac4',1,'VmaDefragmentationInfo']]],
  ['memory_20allocation_3',['Memory allocation',['../group__group__alloc.html',1,'']]],
  ['memory_20mapping_4',['Memory mapping',['../memory_mapping.html',1,'index']]],
  ['memoryheap_5',['memoryHeap',['../struct_vma_total_statistics.html#a39beeba5b3a2e7cfe5f5e2331a2705ce',1,'VmaTotalStatistics']]],
  ['memorytype_6',['memoryType',['../struct_vma_total_statistics.html#acb70e5b7fe543813ed8ba9282640969d',1,'VmaTotalStatistics::memoryType()'],['../struct_vma_allocation_info.html#a7f6b0aa58c135e488e6b40a388dad9d5',1,'VmaAllocationInfo::memoryType()']]],
  ['memorytypebits_7',['memoryTypeBits',['../struct_vma_allocation_create_info.html#a3bf940c0271d85d6ba32a4d820075055',1,'VmaAllocationCreateInfo']]],
  ['memorytypeindex_8',['memoryTypeIndex',['../struct_vma_pool_create_info.html#a596fa76b685d3f1f688f84a709a5b319',1,'VmaPoolCreateInfo']]],
  ['minallocationalignment_9',['minAllocationAlignment',['../struct_vma_pool_create_info.html#ade3eca546f0c6ab4e8fbf20eb6d854cb',1,'VmaPoolCreateInfo']]],
  ['minblockcount_10',['minBlockCount',['../struct_vma_pool_create_info.html#ad8006fb803185c0a699d30f3e9a865ae',1,'VmaPoolCreateInfo']]],
  ['movecount_11',['moveCount',['../struct_vma_defragmentation_pass_move_info.html#a1b3e18c23f9691f35baf183e615c4408',1,'VmaDefragmentationPassMoveInfo']]]
];
