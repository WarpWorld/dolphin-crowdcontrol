var searchData=
[
  ['library_20initialization_0',['Library initialization',['../group__group__init.html',1,'']]]
];
