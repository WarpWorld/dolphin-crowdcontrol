var searchData=
[
  ['pfn_5fvmaallocatedevicememoryfunction_0',['PFN_vmaAllocateDeviceMemoryFunction',['../group__group__init.html#ga7e1ed85f7799600b03ad51a77acc21f3',1,'vk_mem_alloc.h']]],
  ['pfn_5fvmafreedevicememoryfunction_1',['PFN_vmaFreeDeviceMemoryFunction',['../group__group__init.html#ga154ccaaf53dc2c36378f80f0c4f3679b',1,'vk_mem_alloc.h']]]
];
